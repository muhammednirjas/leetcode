package com.leetcode;

public class BuyAndSellStock {
    public static int stockArray(int prices []){
        int minprice =  1000000000;              //Integer.MAX_VALUE;
        int Max_Profit = 0;
        for(int i=0;i< prices.length;i++){
            if(prices[i]<minprice){
                 minprice = prices[i];
            } else if(prices[i] - minprice > Max_Profit){
                Max_Profit = prices[i]- minprice;
               // System.out.println(Max_Profit);
            }
        }
        return Max_Profit;
        //System.out.println(Max_Profit);
    }

    public static void main(String[] args) {
        System.out.println("process");
        int[] stock = {7,1,5,3,6,4};
        System.out.println(stockArray(stock));
        System.out.println("end");

    }
}
